export interface Document {
  name: string;
  icon: string;
  createdDate: Date;
}
