export interface HrEmployee {
  name: string;
  ssn: string;
  visaStatus: string;
  startDate: string;
  endDate: string;
  employeeId: number;
}
